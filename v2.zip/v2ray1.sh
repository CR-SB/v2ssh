#!/bin/bash

#安装v2ray
rm -rf /usr/local/bin/v2ray > /dev/null 2>&1
mkdir /usr/local/bin/v2ray
cp ${0%/*}/v2ray /usr/local/bin/v2ray
cp ${0%/*}/v2ctl /usr/local/bin/v2ray
cp ${0%/*}/config.json /usr/local/bin/v2ray
cp ${0%/*}/config.json /usr/local/bin/v2ray/config.json.bak
chmod 0777 -R /usr/local/bin/v2ray

#启动v2ray
pkill v2ray
rm -rf /etc/v2ray > /dev/null 2>&1
rm -rf /usr/bin/v2ray > /dev/null 2>&1
nohup /usr/local/bin/v2ray/v2ray -config /usr/local/bin/v2ray/config.json > /dev/null 2>&1 &

#控制面板
rm -f /bin/v2 > /dev/null 2>&1
cp ${0%/*}/v2 /bin
chmod +x /bin/v2

#提示
clear
echo " v2ray的安装已完成并且正在运行，输入v2进入控制面板"
echo

#自毁
rm -f $0
